const express=require('express');
const cors=require('cors');
const path=require('path');
const body=require('body-parser');
require('dotenv').config();
const app=express();

app.use(cors());
app.use(body.json());
app.use(express.static(path.join(__dirname,'../public')));

app.use('/api',require('./routes/api'));
app.use('/admin',require('./routes/admin'));
app.use('/merchant',require('./routes/merchant'));

app.listen(process.env.PORT||3000,()=>console.log("C-STAR PRO RUNNING"));
